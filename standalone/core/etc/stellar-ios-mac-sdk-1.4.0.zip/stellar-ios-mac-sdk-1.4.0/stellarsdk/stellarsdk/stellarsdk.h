//
//  stellarsdk.h
//  stellarsdk
//
//  Created by Razvan Chelemen on 26/01/2018.
//  Copyright © 2018 Soneso. All rights reserved.
//


//! Project version number for stellarsdk.
FOUNDATION_EXPORT double stellarsdkVersionNumber;

//! Project version string for stellarsdk.
FOUNDATION_EXPORT const unsigned char stellarsdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <stellarsdk/PublicHeader.h>

//#include <rpc/types.h>
//#include <rpc/xdr.h>


